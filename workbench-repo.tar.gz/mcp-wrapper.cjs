#!/usr/bin/env node
/**
 * MCP Server Wrapper for Windows
 * Handles stdio forwarding between Electron and MCP servers
 */

const { spawn } = require('child_process');

const args = process.argv.slice(2);
if (args.length === 0) {
  console.error('Usage: node mcp-wrapper.js <command> [args...]');
  process.exit(1);
}

// Spawn the MCP server
const child = spawn(args[0], args.slice(1), {
  stdio: ['pipe', 'pipe', 'pipe'],
  shell: true,
  windowsHide: true
});

// Prevent pipes from closing early
process.stdin.setEncoding('utf8');
child.stdin.setDefaultEncoding('utf8');

// Forward stdin
process.stdin.on('data', (data) => {
  child.stdin.write(data);
});

process.stdin.on('end', () => {
  child.stdin.end();
});

// Forward stdout with explicit encoding
child.stdout.setEncoding('utf8');
child.stdout.on('data', (data) => {
  process.stdout.write(data);
});

// Forward stderr
child.stderr.setEncoding('utf8');
child.stderr.on('data', (data) => {
  process.stderr.write(data);
});

// Handle errors
child.on('error', (err) => {
  console.error('MCP wrapper error:', err);
  process.exit(1);
});

// Don't exit when child exits - wait for stdin to close instead
// This is because npx exits after spawning the actual server
child.on('exit', (code, signal) => {
  // Only log, don't exit
  if (code !== 0 && code !== null) {
    console.error(`Child process exited with code ${code}`);
  }
});
