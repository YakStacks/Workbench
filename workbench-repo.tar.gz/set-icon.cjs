// Post-build script to ensure icon is embedded in exe
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

const exePath = path.join(__dirname, 'release', 'win-unpacked', 'Workbench.exe');
const iconPath = path.join(__dirname, 'icon.ico');
const rceditPath = path.join(__dirname, 'node_modules', 'rcedit', 'bin', 'rcedit.exe');

if (fs.existsSync(exePath) && fs.existsSync(iconPath) && fs.existsSync(rceditPath)) {
  console.log('Setting icon on Workbench.exe...');
  try {
    execSync(`"${rceditPath}" "${exePath}" --set-icon "${iconPath}"`);
    console.log('✓ Icon successfully embedded in exe');
  } catch (error) {
    console.error('Failed to set icon:', error.message);
    process.exit(1);
  }
} else {
  console.log('Skipping icon embedding (files not found)');
}
